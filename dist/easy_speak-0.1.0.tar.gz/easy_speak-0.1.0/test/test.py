from easy_speak import easy_speak

if __name__ == "__main__":
    print("What should I say?")
    text = input(">> ")
    easy_speak(text, "en")
